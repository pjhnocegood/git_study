package kr.co.kyu;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KyudemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(KyudemoApplication.class, args);
	}

}
