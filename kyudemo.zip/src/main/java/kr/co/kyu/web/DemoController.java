package kr.co.kyu.web;

import javax.servlet.http.HttpServletRequest;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import kr.co.kyu.util.Curl;

@Controller
public class DemoController {
	
	@Value("${stp.oidkey}")
	String oidkey;
	@Value("${stp.sid}")
	String sid;
	@Value("${stp.SVC_IF_BASE_URL}")
	String SVC_IF_BASE_URL ;

	@RequestMapping(value = "/login")
	public String login(HttpServletRequest request) {

		System.out.println(oidkey);
		System.out.println(sid);
		System.out.println(SVC_IF_BASE_URL);

		request.setAttribute("oidKey", oidkey);
		request.setAttribute("sid", sid);
		request.setAttribute("SVC_IF_BASE_URL", SVC_IF_BASE_URL);
		System.out.println( org.springframework.core.SpringVersion.getVersion() ); 


		return "login";
	}
	
	@RequestMapping(value = "/slogin", method = {RequestMethod.GET,RequestMethod.POST})
	public String login2(HttpServletRequest request , Model model) {

		String oidKey = request.getParameter("oidKey");		// 기관코드
		String sid = request.getParameter("sid");			// 서비스ID
		String userId = request.getParameter("userId");		// 사용자ID
		String userPwd = request.getParameter("userPwd");	// 사용자PWD
		//String SVC_IF_BASE_URL = request.getParameter("SVC_IF_BASE_URL"); //app server URL

		// --------------------------
		// TODO
		// 1. ID/PW 체크
		// ID/PW로 회원가입된 사용자인지 확인한다.
		// --------------------------

		request.setAttribute("OID_KEY", oidKey);	// 기관코드
		request.setAttribute("SID", sid);			// 시스템ID
		request.setAttribute("USER_ID", userId);	// 사용자ID
		request.setAttribute("SVC_IF_BASE_URL", SVC_IF_BASE_URL);//APP서버 URL

		return "login2Factor";
	}
	
	//통합인증 요청
		@SuppressWarnings("unchecked")		
		@PostMapping(value = "/easyauth/req")
		@ResponseBody
		public JSONObject easyAuthReq(HttpServletRequest request) {
			System.out.println("/easyauth/req");
			System.out.println("easyauth coeme;;;");
			String oidKey = request.getParameter("oid_key");	// 기관코드
			String sid = request.getParameter("sid");			// 시스템ID
			String userId = request.getParameter("user_id");	// 사용자ID
			//String SVC_IF_BASE_URL = request.getParameter("SVC_IF_BASE_URL"); //app server URL

			// --------------------------
			// 1. 통합인증 요청 인터페이스에 보낼 데이터 설정
			// --------------------------
			JSONObject jsonReq = new JSONObject();
			jsonReq.put("OID_KEY", oidKey);	// 기관코드
			jsonReq.put("SID", sid);		// 시스템ID
			jsonReq.put("USER_ID", userId);	// 사용자ID

			System.out.println(jsonReq.get("OID_KEY").toString()+jsonReq.get("SID").toString()+jsonReq.get("USER_ID").toString() + "===============================?");
			// --------------------------
			// 2. 통합인증 요청
			// --------------------------
			String strRes = Curl.post(SVC_IF_BASE_URL + "/svcif/easyauth/req", new String[] {"Content-Type application/json;charset=UTF-8"}, jsonReq.toString());
			System.out.println("[login] Login Request Response: " + strRes);

			JSONObject jsonRes = null;
			try {
				jsonRes = (JSONObject) new JSONParser().parse(strRes);
			} catch (ParseException e) {
				e.printStackTrace();
			}



			if ( jsonRes == null ) {
				throw new NullPointerException("Login Request Response is null");
			}

			// 모바일 디바이스여부 체크
			String userAgent = request.getHeader("User-Agent");
			boolean mobileOS = isMobile(userAgent);

			// 통합인증 요청이 성공하면 통합인증 앱을 실행시키기 위해 push를 전송한다.
			// 데스크탑 디바이스에서만 push를 전송한다.
			boolean result = (Boolean) jsonRes.get("RESULT"); //true


			if ( !mobileOS && result ) {

				// --------------------------
				// 3. push로 통합인증 앱에 보낼 데이터 설정
				// push는 자체 push 권장
				// --------------------------
				jsonReq = new JSONObject();
				jsonReq.put("ACCESS_TOKEN", (String) jsonRes.get("ACCESS_TOKEN"));	// 토큰
				jsonReq.put("ACTION", "MainActivity");	// 실행Activity

				String RESULT_CODE = jsonRes.get("RESULT_CODE").toString();  //resultcode
				//RESULT_CODE="23"; //통신오류 test
				System.out.println(RESULT_CODE+ "===================resultCode");
				
				if(RESULT_CODE.equals("023") || RESULT_CODE.equals("024")) { //예외 코드
					System.out.println("코듴도ㅡ");
					jsonRes.put("MESSAGE", "인증데이터와 통신이 원할하지 않습니다.");
					jsonRes.put("RESULT_CODE",RESULT_CODE);
				
					return jsonRes;
					
				}
				

				// --------------------------
				// 4. 통합인증 앱 push 전송
				// --------------------------
				strRes = Curl.post(SVC_IF_BASE_URL + "/svcif/push/send", new String[] {"Content-Type application/json;charset=UTF-8"}, jsonReq.toString());
				System.out.println("[login] Push Send Response: " + strRes);

				JSONObject jsonPushRes = null;
				try {
					jsonPushRes = (JSONObject) new JSONParser().parse(strRes);
				} catch (ParseException e) {
					e.printStackTrace();
				}

				if ( jsonPushRes == null ) {
					throw new NullPointerException("Push Send Response is null");
				}

				result = (Boolean) jsonPushRes.get("RESULT"); //true
				if ( !result ) {  //false
					return jsonPushRes;
				}

			}

			return jsonRes;

		}
		
		//통하빈증 완료 여부 확인
			@SuppressWarnings("unchecked")
			@RequestMapping(value = "/authCheck", method = RequestMethod.POST)
			@ResponseBody
			public JSONObject authCheck(HttpServletRequest request) {
				System.out.println("/authCheck");
				String accessToken = request.getParameter("access_token");	// 토큰
				//String SVC_IF_BASE_URL = request.getParameter("SVC_IF_BASE_URL"); //app server URL
				
				// --------------------------
				// 1. 통합인증 완료여부 확인 인터페이스에 보낼 데이터 설정
				// --------------------------
				JSONObject jsonReq = new JSONObject();
				jsonReq.put("ACCESS_TOKEN", accessToken);	// 토큰

				// --------------------------
				// 2. 통합인증 완료여부 확인
				// --------------------------
				String strRes = Curl.post(SVC_IF_BASE_URL + "/svcif/easyauth/check", new String[] {"Content-Type application/json;charset=UTF-8"}, jsonReq.toString());
				
				System.out.println("[authCheck] EasyAuth Check Response: " + strRes);
				
				JSONObject jsonRes = null;
				try {
					jsonRes = (JSONObject) new JSONParser().parse(strRes);
				} catch (ParseException e) {
					e.printStackTrace();
				}
				
				if ( jsonRes == null ) {
					throw new NullPointerException("[authCheck] EasyAuth Check Response is null");
				}
				
				return jsonRes;
				
			}
			
			//MOPT 확인
			@SuppressWarnings("unchecked")
			@RequestMapping(value = "/motp/login", method = RequestMethod.POST)
			@ResponseBody
			public JSONObject motpLogin(HttpServletRequest request) {
				System.out.println("/motp/login");
				String accessToken = request.getParameter("access_token");	// 토큰
				String userOtp = request.getParameter("userOtp");			// MOTP번호
				String otpType = request.getParameter("otpType");			// MOTP타입
				//String SVC_IF_BASE_URL = request.getParameter("SVC_IF_BASE_URL"); //app server URL
				// --------------------------
				// 1. MOTP번호 확인 인터페이스에 보낼 데이터 설정
				// --------------------------
				JSONObject jsonReq = new JSONObject();
				jsonReq.put("ACCESS_TOKEN", accessToken);	// 토큰
				jsonReq.put("USERPW", userOtp);				// MOTP번호
				jsonReq.put("OTPTYPE", otpType);			// MOTP타입
				
				// --------------------------
				// 2. MOTP번호 확인
				// --------------------------
				String strRes = Curl.post(SVC_IF_BASE_URL + "/svcif/motp/check", new String[] {"Content-Type application/json;charset=UTF-8"}, jsonReq.toString());
				System.out.println("[motpLogin] MOTP Check Response: " + strRes);
				
				JSONObject jsonRes = null;
				try {
					jsonRes = (JSONObject) new JSONParser().parse(strRes);
				} catch (ParseException e) {
					e.printStackTrace();
				}
				
				if ( jsonRes == null ) {
					throw new NullPointerException("[motpLogin] MOTP Check Response is null");
				}
				
				return jsonRes;
				
			}
			
			//로그인 완료화면
			@RequestMapping(value = "/loginSuccess")
			public String loginSuccess(HttpServletRequest request) {
				System.out.println("/loginSuccess");
//				String userId = request.getParameter("user_id");	// 사용자ID
//				
//				request.setAttribute("SID", sid);
//				request.setAttribute("USER_ID", userId);
				
				return "login_success";
				
			}
			
//			@RequestMapping(value = "/demo/sloginSuccess")
//			public String sloginSuccess(HttpServletRequest request, @PathVariable String sid) {
//				
//				request.setAttribute("SID", sid);
//				
//				return "/ssenstone/login_success";
//				
//			}
	//	

		//모바일 체크
		private boolean isMobile(String userAgent) {

			boolean flag = false;

			String[] mobileOS = {"iPhone","iPod","Android","BlackBerry","windows CE","Nokia","Webos","Opera Mini","SonyEricsson","Opera Mobi","IEMobile"};

			if ( userAgent != null && !"".equals(userAgent) ) {
				for ( String s : mobileOS ) {
					if ( userAgent.indexOf(s) > -1 ) {
						flag = true;
						break;
					}
				}
			}

			return flag;

		}

}
