//document.write('<script type="text/javascript" src="/jj/_js/user/facebook.js"></script>');
//document.write('<script type="text/javascript" src="/jj/_js/user/jquery.swipebox.js"></script>');

//메인 슬라이더 모바일용 이미지 로드
$(function() {
    var filter = "win16|win32|win64|mac|macintel";
    
    if ( navigator.platform ) {
        if ( filter.indexOf( navigator.platform.toLowerCase() ) < 0 ) {
            //mobile
            var width = window.innerWidth;
            
            if(width < 768){
                $('#simg-1').attr('src', '../../jj/_res/img/main/visual_vimeo_1_s.jpg');
                $('#simg-2').attr('src', '../../jj/_res/img/main/visual_001_s.jpg');
                $('#simg-3').attr('src', '../../jj/_res/img/main/visual_vimeo_2_s.jpg');
                $('#simg-4').attr('src', '../../jj/_res/img/main/visual_002_s.jpg');
                $('#simg-5').attr('src', '../../jj/_res/img/main/visual_vimeo_3_s.jpg');
                $('#simg-6').attr('src', '../../jj/_res/img/main/visual_003_s.jpg');
                $('#simg-7').attr('src', '../../jj/_res/img/main/visual_vimeo_4_s.jpg');
                $('#simg-8').attr('src', '../../jj/_res/img/main/visual_004_s.jpg');
                $('#simg-9').attr('src', '../../jj/_res/img/main/visual_005_s.jpg');
                $('#simg-10').attr('src', '../../jj/_res/img/main/visual_006_s.jpg');
                $('#simg-11').attr('src', '../../jj/_res/img/main/visual_007_s.jpg');
                $('#simg-12').attr('src', '../../jj/_res/img/main/visual_008_s.jpg');
                $('#simg-13').attr('src', '../../jj/_res/img/main/visual_009_s.jpg');
                $('#simg-14').attr('src', '../../jj/_res/img/main/visual_010_s.jpg');
                $('#simg-15').attr('src', '../../jj/_res/img/main/visual_011_s.jpg');
                $('#simg-16').attr('src', '../../jj/_res/img/main/visual_vimeo_5_s.jpg');
                $('#simg-17').attr('src', '../../jj/_res/img/main/visual_012_s.jpg');
                $('#simg-18').attr('src', '../../jj/_res/img/main/visual_013_s.jpg');
                $('#simg-19').attr('src', '../../jj/_res/img/main/visual_014_s.jpg');
                $('#simg-20').attr('src', '../../jj/_res/img/main/visual_015_s.jpg');
                $('#simg-21').attr('src', '../../jj/_res/img/main/visual_016_s.jpg');
                $('#simg-22').attr('src', '../../jj/_res/img/main/visual_017_s.jpg');
                $('#simg-23').attr('src', '../../jj/_res/img/main/visual_018_s.jpg');
                $('#simg-24').attr('src', '../../jj/_res/img/main/visual_019_s.jpg');
                $('#simg-25').attr('src', '../../jj/_res/img/main/visual_020_s.jpg');
                $('#simg-26').attr('src', '../../jj/_res/img/main/visual_021_s.jpg');
                $('#simg-27').attr('src', '../../jj/_res/img/main/visual_022_s.jpg');
                $('#simg-28').attr('src', '../../jj/_res/img/main/visual_023_s.jpg');
                $('#simg-29').attr('src', '../../jj/_res/img/main/visual_024_s.jpg');
                $('#simg-30').attr('src', '../../jj/_res/img/main/visual_025_s.jpg');
                $('#simg-31').attr('src', '../../jj/_res/img/main/visual_026_s.jpg');
                $('#simg-32').attr('src', '../../jj/_res/img/main/visual_027_s.jpg');
                $('#simg-33').attr('src', '../../jj/_res/img/main/visual_028_s.jpg');
                $('#simg-34').attr('src', '../../jj/_res/img/main/visual_029_s.jpg');
                $('#simg-35').attr('src', '../../jj/_res/img/main/visual_030_s.jpg');
                $('#simg-36').attr('src', '../../jj/_res/img/main/visual_031_s.jpg');
                $('#simg-37').attr('src', '../../jj/_res/img/main/visual_032_s.jpg');
                $('#simg-38').attr('src', '../../jj/_res/img/main/visual_033_s.jpg');
                $('#simg-39').attr('src', '../../jj/_res/img/main/visual_034_s.jpg');
                $('#simg-40').attr('src', '../../jj/_res/img/main/visual_035_s.jpg');
                $('#simg-41').attr('src', '../../jj/_res/img/main/visual_036_s.jpg');
                $('#simg-42').attr('src', '../../jj/_res/img/main/visual_037_s.jpg');
                $('#simg-43').attr('src', '../../jj/_res/img/main/visual_038_s.jpg');
                $('#simg-44').attr('src', '../../jj/_res/img/main/visual_039_s.jpg');
                $('#simg-45').attr('src', '../../jj/_res/img/main/visual_040_s.jpg');
                $('#simg-46').attr('src', '../../jj/_res/img/main/visual_041_s.jpg');
                $('#simg-47').attr('src', '../../jj/_res/img/main/visual_042_s.jpg');
                $('#simg-48').attr('src', '../../jj/_res/img/main/visual_043_s.jpg');
                $('#simg-49').attr('src', '../../jj/_res/img/main/visual_044_s.jpg');
                $('#simg-50').attr('src', '../../jj/_res/img/main/visual_045_s.jpg');
                $('#simg-51').attr('src', '../../jj/_res/img/main/visual_046_s.jpg');
                $('#simg-52').attr('src', '../../jj/_res/img/main/visual_047_s.jpg');
                $('#simg-53').attr('src', '../../jj/_res/img/main/visual_048_s.jpg');
                $('#simg-54').attr('src', '../../jj/_res/img/main/visual_049_s.jpg');
                $('#simg-55').attr('src', '../../jj/_res/img/main/visual_050_s.jpg');
                $('#simg-56').attr('src', '../../jj/_res/img/main/visual_051_s.jpg');
                $('#simg-57').attr('src', '../../jj/_res/img/main/visual_052_s.jpg');
                $('#simg-58').attr('src', '../../jj/_res/img/main/visual_053_s.jpg');
                $('#simg-59').attr('src', '../../jj/_res/img/main/visual_054_s.jpg');
                $('#simg-60').attr('src', '../../jj/_res/img/main/visual_055_s.jpg');
                $('#simg-61').attr('src', '../../jj/_res/img/main/visual_056_s.jpg');
                $('#simg-62').attr('src', '../../jj/_res/img/main/visual_057_s.jpg');
                $('#simg-63').attr('src', '../../jj/_res/img/main/visual_058_s.jpg');
                $('#simg-64').attr('src', '../../jj/_res/img/main/visual_059_s.jpg');
                $('#simg-65').attr('src', '../../jj/_res/img/main/visual_060_s.jpg');
                $('#simg-66').attr('src', '../../jj/_res/img/main/visual_061_s.jpg');
                $('#simg-67').attr('src', '../../jj/_res/img/main/visual_062_s.jpg');
                $('#simg-68').attr('src', '../../jj/_res/img/main/visual_063_s.jpg');
                $('#simg-69').attr('src', '../../jj/_res/img/main/visual_064_s.jpg');
                $('#simg-70').attr('src', '../../jj/_res/img/main/visual_065_s.jpg');
                $('#simg-71').attr('src', '../../jj/_res/img/main/visual_066_s.jpg');
                $('#simg-72').attr('src', '../../jj/_res/img/main/visual_067_s.jpg');
              
                $('#vimg-1').attr('src', '../../jj/_res/img/main/svisual_001_s.jpg');
                $('#vimg-2').attr('src', '../../jj/_res/img/main/svisual_002_s.jpg');
                $('#vimg-3').attr('src', '../../jj/_res/img/main/svisual_003_s.jpg');
            }
        }
    }
});

$(document).ready(function(){
	$('.m_visual01 .m01').after('<div class="mleft"/><div class="mright"/>');

	resize();
	$(window).resize(resize);
});

function resize(){
  
	x = window.innerWidth;

	//main
	$('.m_news').outerWidth($('.con').width() - $('.con01').outerWidth());
	$('.m_visual02 .v_list, .m_visual02 .m02').height($('.m_visual02 .v_list li').height()); // 0624
	$('.m_link02 ul').outerWidth($('.con').width() - $('.m_btn_area02 .btn_prev').width() * 2);
    $('.m_visual01 .m01 ul').css('width','1180px');
      
	if(x > 1180){
		var mg = (x - 1180) / 2;
		$('.m_visual01 .m01 > div').css('margin-left',mg -7).css('margin-right',mg -8);
		$('.m_visual01 .mleft').css('width',mg - 7).css('height',$('.m_visual01 ul li').height());
		$('.m_visual01 .mright').css('width',mg - 8).css('height',$('.m_visual01 ul li').height());
	}

	if(x <= 1180){
		$('.m_visual01 ul, .m_visual01 ul li').height(x * 0.424);
		$('.m_visual02 .v_list, .m_visual02 .v_list li, .m_visual02 .m02').height(x * 0.347); // 0624
	} else {
		$('.m01 > div, .m_visual01 ul, .m_visual01 ul li').height(500);
		$('.m02, .m02 > .v_list, .m02 > .v_list > li').height(398);

        $('.m_visual01 .mleft').css('width',mg - 7).css('height',$('.m_visual01 ul li').height());
		$('.m_visual01 .mright').css('width',mg - 8).css('height',$('.m_visual01 ul li').height());
    }//0914수정

	
	if(x > 1000){
		//mian link
		$(".m_link02 .list").touchSlider({
			autoplay : {
				enable : true,
				pauseHover : true,
				interval : 9000,
			},
			view : 4,
			roll : true,
			btn_prev : $(".m_link02 .list").next().find(".btn_prev"),
			btn_next : $(".m_link02 .list").next().find(".btn_next")
		});
		$('#mContainer , footer, #container').show();

		//sub content
		$('.content').width($('.container').width() - $('.lnb').outerWidth() - 30 - 60);

	}

	if(x <= 1000){
		//mian link
		$(".m_link02 .list").touchSlider({
			autoplay : {
				enable : true,
				pauseHover : true,
				interval : 9000,
			},
			roll : true,
			btn_prev : $(".m_link02 .list").next().find(".btn_prev"),
			btn_next : $(".m_link02 .list").next().find(".btn_next")
		});

		//sub content
		$('.content').width($('.container').width());

	}

}
var maxHeight = 0;
$(function(){
	x = window.innerWidth;

	// gnb web

	$('nav.webnav .depth02').css('visibility','hidden');
	$('nav.webnav .depth01 > li').mouseover(function(){
		$('nav.webnav .depth01 > li > a').removeClass('active');
		$(this).parent().children().children('.depth02').css('visibility','hidden');
		$(this).children('a').addClass('active');
		$(this).children('.depth02').css('visibility','visible');
      
        //var wheight = $(this).find('>ul').height();
        //$('.header').stop(true).animate({height:160+maxHeight},300);      
	});  
	$('nav.webnav .depth01 > li').mouseout(function(){
		if($('header').height() <= 160){
			$('nav.webnav .depth01 > li > a').removeClass('active');
		}
	});

	$('nav.webnav').parent().parent().css('overflow','hidden');
  
	$('nav.webnav .depth01 > li > a').click(function(){
        //var wheight = $(this).next().height();
      
		$(this).attr('href','#none');
		$('.webnav .close').css('visibility','visible');
		$('.header').stop(true).animate({height:160+maxHeight},300);

		//메뉴 열려 있을때 1depth click 하면 메뉴 닫힘 0624
		var headerH = $('.header').height();
		if(headerH > 160){
			$(this).parent().parent().parent().parent().parent().animate({height:160},280);
		}
	});
	$('.webnav .close').click(function(){
		$(this).parent().parent().parent().stop(true).animate({height:160},300);
		//$(this).css('visibility','hidden');
		$('nav.webnav .depth01 > li > a').removeClass('active');
	});


	//gnb mobile
	
	$('.header').before($('.header nav.mnav'));

	$('#wrap > nav .depth01 > li > a').next('.depth02').prev('a').append('<span/>');
	$('#wrap > nav .depth02 > li > a').next('.depth03').prev('a').append('<span/>');

	$('#wrap nav.mnav .depth02, #wrap nav.mnav .depth03').hide();
	$('.mopen').click(function(){
		if($('footer, #container').is(':visible')){
			$('#wrap nav.mnav').height($(window).height() - $('.header').outerHeight());
			$('#wrap nav.mnav').animate({left:'0'},300);
			$('footer, #container').fadeOut();
		}else{
			$('#wrap nav.mnav').animate({left:'-100%'},300);
			$('#mContainer , footer, #container').fadeIn();
		}
	});

	$('#wrap nav.mnav .depth01 > li > a').click(function(){
		$(this).attr('href','#none');
		if($(this).next().is(':hidden')){
			$('#wrap nav.mnav .depth01 > li > a, #wrap nav.mnav .depth02 > li > a').removeClass('active');
			$(this).addClass('active');
			$(this).parent().parent().find('.depth02, .depth03').slideUp();
			$(this).next().slideDown();
		}else{
			$(this).next().slideUp();
			$(this).removeClass('active');
		}
	});

	$('#wrap nav.mnav .depth02 > li > a').click(function(){
		$('#wrap nav.mnav .depth03').parent().find('a:first').attr('href','#none');
		if($(this).next().is(':hidden')){
			$('#wrap nav.mnav .depth02 > li > a').removeClass('active');
			$(this).addClass('active');
			$(this).parent().parent().find('.depth03').slideUp();
			$(this).next().slideDown();
		}else{
			$('#wrap nav.mnav .depth02 > li > a').next().slideUp();
			$('#wrap nav.mnav .depth02 > li > a').removeClass('active');    
		}
	});
	
	// lnb
	$('.lnb .depth02').hide();
	$('.lnb .depth02').parent().find('a:first').attr('href','#none');

	$('.lnb .depth01 > li > a').click(function(){
	if($(this).next().is(':hidden')){
	      $('.lnb .depth01 > li > a').removeClass('active');
	      $(this).addClass('active');
	      $(this).parent().parent().find('.depth02').slideUp(200);
	      $(this).next('.depth02').slideDown(200);
	  }else{
	      $(this).next('.depth02').slideUp(200);
	      $(this).removeClass('active');
	  }
	});
  
    // 3뎁스 열려있게
    var aTag = $(".depth02").find("a.active");
    aTag.parent().parent().css("display", "block");
	
});
$(function () {

	$('.tab_menu ul li').hover(function () {
		$(this).addClass('hover');
	}, function () {
		$(this).removeClass('hover');
	});
	var $menu = $('#tab_menu'), $menulink = $('#spinner-form');
	$menulink.click(function (e) {
		$menu.toggleClass('active');
	});
	var label = $('.tab_menu .hover').find('a').text();    
	$('.tab_select_label').text(label);

	$(".scroll").append("<div class=\"msg_touch_help\"><img src=\"../../jj/_res/img/comm/btn_table_scroll.png\" alt=\"touch slide\"></div>");
	$(".scroll").each(function() {
		$(this).scroll(function() {
			$(this).find(".msg_touch_help").fadeOut();
		});
	});
});

$(function () {
    // 탭메뉴 유형2
	$('.tab_menu2 ul li').hover(function () {
		$(this).addClass('hover');
	}, function () {
		$(this).removeClass('hover');
	});
	var $menu = $('#tab_menu2'), $menulink = $('#spinner-form');
	$menulink.click(function (e) {
		$menu.toggleClass('active');
	});
	var label = $('.tab_menu2 .hover').find('a').text();    
	$('.tab_select_label').text(label);
  
});


$(function() {
  
  
  $('.webnav .depth02').each(function() {
    
    var $this = $(this);
    var max1 = 0, max2 = 0;
    var lis = $this.find('>li');
    var offset;
    for(var i=0; i <lis.length; i++) {
      if(i==0) {
        offset = $(lis[i]).offset();
      }
      
      var h = $(lis[i]).outerHeight();

      
      if($(lis[i]).offset().top == offset.top) {
        max1 = h > max1 ? h: max1;
      } else {
        max2 = h > max2 ? h : max2;
      }
    }
    
    for(var i=0; i <lis.length; i++) {
      if($(lis[i]).offset().top == offset.top) {
        $(lis[i]).css('height',max1);
      } else {
        $(lis[i]).css('height',max2);
      }
      if(i == 6) {
        //$(lis[i]).css('border-left','1px solid #d4d4d4');
      }
    }
    
    var thisHeight = $this.outerHeight();

    maxHeight = thisHeight > maxHeight ? thisHeight: maxHeight;
    
  });
  maxHeight += 20;
  $('.close').css('bottom', -maxHeight);
    
  
});


$(window).on('resize', function () {
    
  $('.webnav .depth02').each(function() {
    
    var $this = $(this);
    var max1 = 0, max2 = 0;
    var lis = $this.find('>li');
    var offset;
    for(var i=0; i <lis.length; i++) {
      if(i==0) {
        offset = $(lis[i]).offset();
      }
      
      //var h = $(lis[i]).outerHeight();
      
      var h = $(lis[i]).find('>a').outerHeight()+ $(lis[i]).find('ul.depth03').outerHeight() + 30 ;
     // console.log(h);
      
      if($(lis[i]).offset().top == offset.top) {
        max1 = h > max1 ? h: max1;
      } else {
        max2 = h > max2 ? h : max2;
      }
    }
    
    for(var i=0; i <lis.length; i++) {
      if($(lis[i]).offset().top == offset.top) {
        $(lis[i]).css('height',max1);
      } else {
        $(lis[i]).css('height',max2);
      }
      if(i == 6) {
        //$(lis[i]).css('border-left','1px solid #d4d4d4');
      }
    }
    
    var thisHeight = $this.outerHeight();

    maxHeight = thisHeight > maxHeight ? thisHeight: maxHeight;
    
  });
 // maxHeight += 20;
  $('.close').css('bottom', -maxHeight);
    
});

$(document).ready(function(){
    //lnb 높이에 따른 inner 클래스 높이 조정 by 형건영
    var eval_height = $('nav.lnb').height() - 220;
    $('div#jwxe_main_content > div.inner').css('min-height', eval_height + 'px');
    $('div#jwxe_main_content + div > div.inner').css('min-height', eval_height + 'px');
    
    // 외부 링크 메뉴의 아이콘 표시
    $('.webnav .depth02 li a[href^="http"]').addClass('extlink');
    $('.lnb .depth02 li a[href^="http"]').addClass('extlink-lnb');
    $('.mnav .depth02 li a[href^="http"]').addClass('extlink-mnav');
    $('.mnav .depth03 li a[href^="http"]').addClass('extlink-mnav');
    
    //$('.swipebox').swipebox();
    
    // 캠퍼스지도(앱)
    $('.tab_menu3 li').click(function(e){
        $('.tab_menu3 li').removeClass('active');
        $(this).addClass('active');
    });
});