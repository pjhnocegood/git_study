document.write('<script type="text/javascript" src="https://www.google.com/recaptcha/api.js"></script>');

if(!App) App = {};

App.login = function() {
	
	var self, timeOut;
	
	return {
		
		init: function() {
			
			self = this;
						
            //loadJavascript('../../../_common/js/toastr.js');            
            //loadCSS('../../../_common/css/toastr.css');
            
            if($.readCookie('reid_chk')) {
              $('#save_id').attr('checked','checked');
              $('#member_id').attr('value',$.readCookie('reid_chk'));
            }
          
			
          
		},
		
		/**
		 * 추가 유효성 체크
		 */
		validate: function() {
         // console.log('test');
          if($('#save_id:checked').length > 0) {
            $.setCookie( 'reid_chk', $('#member_id').val(), {
              duration : 0, // In days
              path : '/',
              domain : '',
              secure : false
            });
          } else {
            $.setCookie('reid_chk', '', {
              duration : 0, // In days
              path : '/',
              domain : '',
              secure : false
            });
          }
          
          return true;      
			
		}
      
      
       
    }
	
}();


$(function() {
	
	App.login.init( );
	
});