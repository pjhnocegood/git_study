var MAX_DAY = 90;

(function($) {
	
	$(document).keydown(function(e) {
		
		if ( e.target.nodeName.toUpperCase() !== 'INPUT' && e.target.nodeName.toUpperCase() !== 'TEXTAREA' ) {
			
			if ( e.keyCode === 8 ) {
				
				return false;
				
			}
			
		}
		
	});
	
	$.ajaxSetup({
	       beforeSend: function(xhr) {
	        xhr.setRequestHeader("AJAX", true);
	    },
	    error: function(xhr, status, err) {
	    	loading.hide();
	        if (xhr.status == 401) {
	        	alert("예외가 발생했습니다. 관리자에게 문의하세요.");
	        } else if (xhr.status == 900) {
	        	alert("세션이 만료되었습니다.");
	        	location.href = "/index.jsp";
	        } else if (xhr.status == 901) {
	        	alert("해당 메뉴에 대한 접근권한이 없습니다.");
	        	location.href = "/main/main.do";
	        } else if (xhr.status == 902) {
	        	alert("사용자 PC의 아이피 정보가 변경되어 서비스 이용이 불가능 합니다. 다시 로그인해 주시기 바랍니다.");
	        	location.href = "/sign/logout.do";
	        }  else {
	            alert("서버와 통신 중 에러가 발생하였습니다.");
	        }
	    },
	    complete : function(xhr) {
	    	//loading.hide();
	    }
	});
	
})(jQuery);

/**
 * 숫자만 입력 가능
 */
function numberOnlyHandler() {
	
	var regExp = /^[ㄱ-ㅎ가-힣]+/;
	
	$('.numOnly').css('imeMode', 'disabled').keypress(function(event) {
		if(event.which && (event.which < 48 || event.which > 57) && event.which != 8 ) {
			event.preventDefault();
		}
	}).keyup(function() {
		
		var $this = $(this)
		if($this.val() != null && $this.val() != '' ) {
			
			if ( regExp.test($this.val()) ) {
				$this.val( $this.val().replace(/[^0-9]/g,'') );
			}
			
		}
		
	});
	
}

function wrapWindowByMask() {
	var maskHeight = $(document).height();  
	var maskWidth = $(window).width();
	var $mask = $('.mask');
		
	$mask.css({'width':maskWidth,'height':maskHeight}).show();  
}

var loading = {};
loading = {
	
		show : function() {
			wrapWindowByMask();
		},
		hide : function() {
			$('#mask').hide();
		}
		
};

var layer_confirm = {};
layer_confirm = {
	
		show : function() {
			wrapWindowByMask();
		},
		hide : function() {
			$('#layer_mask').hide();
		}
		
};

function iosCheck() {
	
	if ( /iPhone|iPad|iPod/i.test(navigator.userAgent) ) {
		return true;
	}
	
	return false;
	
}