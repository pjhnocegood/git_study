package kr.co.gyu.util;

import java.util.Properties;

/**
 * 프로퍼티 Util
 * @since 2016.11.30
 * @author kimil
 * @version 1.0
 * 
 * <pre>
 * << 개정 이력 >>
 * 
 * 		수정일					수정자											수정내용
 * ----------------		---------------------			--------------------------------------------------------
 * 	  2016.11.30				김효일					최초작성
 * 
 * </pre>
 */
public class PropertyUtil {

	public static Properties properties;
	
	public static Properties setInstance(Properties prop) {
		properties = prop;
		return properties;
	}
	
	public static int getLimitList() {
		return Integer.parseInt(getProperty("limit.list"));
	}
	
	public static int getLimitPage() {
		return Integer.parseInt(getProperty("limit.page"));
	}
	
	public static String getProperty(String key) {
		return properties.getProperty(key);
	}
	
	public static int getPropertyInt(String key) {
		return Integer.parseInt(properties.getProperty(key));
	}
}
