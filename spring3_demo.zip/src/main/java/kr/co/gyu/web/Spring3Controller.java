package kr.co.gyu.web;

import java.text.DateFormat;
import java.util.Date;
import java.util.Locale;

import javax.servlet.http.HttpServletRequest;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import kr.co.gyu.util.Curl;




@Controller
public class Spring3Controller {	
	@Value("#{config['SVC_IF_BASE_URL']}") //
	private String SVC_IF_BASE_URL; //APP서버 URL

	
	//로그인 화면
	@RequestMapping(value = "/spring3/login", method = {RequestMethod.GET,RequestMethod.POST})
	public String login(HttpServletRequest request , Model model) {
		System.out.println(org.springframework.core.SpringVersion.getVersion());
		return "/spring3/login";
	}

	//인증요청 화면
	@RequestMapping(value = "/slogin", method = {RequestMethod.GET,RequestMethod.POST})
	public String login2(HttpServletRequest request , Model model) {

		String oidKey = request.getParameter("oidKey");		// 기관코드
		String sid = request.getParameter("sid");			// 서비스ID
		String userId = request.getParameter("userId");		// 사용자ID
		String userPwd = request.getParameter("userPwd");	// 사용자PWD
		//String SVC_IF_BASE_URL = request.getParameter("SVC_IF_BASE_URL"); //app server URL

		// --------------------------
		// TODO
		// 1. ID/PW 체크
		// ID/PW로 회원가입된 사용자인지 확인한다.
		// --------------------------

		request.setAttribute("OID_KEY", oidKey);	// 기관코드
		request.setAttribute("SID", sid);			// 시스템ID
		request.setAttribute("USER_ID", userId);	// 사용자ID
		request.setAttribute("SVC_IF_BASE_URL", SVC_IF_BASE_URL);//APP서버 URL

		return "spring3/login2Factor";
	}
	
	//통합인증 요청
	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/easyauth/req", method = { RequestMethod.POST,RequestMethod.GET})
	@ResponseBody
	public JSONObject easyAuthReq(HttpServletRequest request) {
		
		String oidKey = request.getParameter("oid_key");	// 기관코드
		String sid = request.getParameter("sid");			// 시스템ID
		String userId = request.getParameter("user_id");	// 사용자ID
		//String SVC_IF_BASE_URL = request.getParameter("SVC_IF_BASE_URL"); //app server URL

		// --------------------------
		// 1. 통합인증 요청 인터페이스에 보낼 데이터 설정
		// --------------------------
		JSONObject jsonReq = new JSONObject();
		jsonReq.put("OID_KEY", oidKey);	// 기관코드
		jsonReq.put("SID", sid);		// 시스템ID
		jsonReq.put("USER_ID", userId);	// 사용자ID

		// --------------------------
		// 2. 통합인증 요청
		// --------------------------
		String strRes = Curl.post(SVC_IF_BASE_URL + "/svcif/easyauth/req", new String[] {"Content-Type application/json;charset=UTF-8"}, jsonReq.toString());
		System.out.println("[login] Login Request Response: " + strRes);

		JSONObject jsonRes = null;
		try {
			jsonRes = (JSONObject) new JSONParser().parse(strRes);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		
		
		
		if ( jsonRes == null ) {
			throw new NullPointerException("Login Request Response is null");
		}

		// 모바일 디바이스여부 체크
		String userAgent = request.getHeader("User-Agent");
		boolean mobileOS = isMobile(userAgent);

		// 통합인증 요청이 성공하면 통합인증 앱을 실행시키기 위해 push를 전송한다.
		// 데스크탑 디바이스에서만 push를 전송한다.
		boolean result = (Boolean) jsonRes.get("RESULT"); //true
		
		
		if ( !mobileOS && result ) {

			// --------------------------
			// 3. push로 통합인증 앱에 보낼 데이터 설정
			// push는 자체 push 권장
			// --------------------------
			jsonReq = new JSONObject();
			jsonReq.put("ACCESS_TOKEN", (String) jsonRes.get("ACCESS_TOKEN"));	// 토큰
			jsonReq.put("ACTION", "MainActivity");	// 실행Activity
			
			String RESULT_CODE = jsonRes.get("RESULT_CODE").toString();  //resultcode
			//RESULT_CODE="23"; //통신오류 test
					
			if(RESULT_CODE.equals("023") || RESULT_CODE.equals("024")) { //예외 코드				
				jsonRes.put("MESSAGE", "인증데이터와 통신이 원할하지 않습니다.");
				jsonRes.put("RESULT_CODE",RESULT_CODE);				
				return jsonRes;
			}
			
			
			// --------------------------
			// 4. 통합인증 앱 push 전송
			// --------------------------
			strRes = Curl.post(SVC_IF_BASE_URL + "/svcif/push/send", new String[] {"Content-Type application/json;charset=UTF-8"}, jsonReq.toString());
			System.out.println("[login] Push Send Response: " + strRes);

			JSONObject jsonPushRes = null;
			try {
				jsonPushRes = (JSONObject) new JSONParser().parse(strRes);
			} catch (ParseException e) {
				e.printStackTrace();
			}

			if ( jsonPushRes == null ) {
				throw new NullPointerException("Push Send Response is null");
			}

			result = (Boolean) jsonPushRes.get("RESULT"); //true
			if ( !result ) {  //false
				return jsonPushRes;
			}

		}

		return jsonRes;

	}
	
	//통하빈증 완료 여부 확인
	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/authCheck", method = RequestMethod.POST)
	@ResponseBody
	public JSONObject authCheck(HttpServletRequest request) {
		
		String accessToken = request.getParameter("access_token");	// 토큰
		//String SVC_IF_BASE_URL = request.getParameter("SVC_IF_BASE_URL"); //app server URL
		
		// --------------------------
		// 1. 통합인증 완료여부 확인 인터페이스에 보낼 데이터 설정
		// --------------------------
		JSONObject jsonReq = new JSONObject();
		jsonReq.put("ACCESS_TOKEN", accessToken);	// 토큰

		// --------------------------
		// 2. 통합인증 완료여부 확인
		// --------------------------
		String strRes = Curl.post(SVC_IF_BASE_URL + "/svcif/easyauth/check", new String[] {"Content-Type application/json;charset=UTF-8"}, jsonReq.toString());
		
		System.out.println("[authCheck] EasyAuth Check Response: " + strRes);
		
		JSONObject jsonRes = null;
		try {
			jsonRes = (JSONObject) new JSONParser().parse(strRes);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		
		if ( jsonRes == null ) {
			throw new NullPointerException("[authCheck] EasyAuth Check Response is null");
		}
		
		return jsonRes;
		
	}
	
	//MOPT 확인
	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/motp/login", method = RequestMethod.POST)
	@ResponseBody
	public JSONObject motpLogin(HttpServletRequest request) {
		
		String accessToken = request.getParameter("access_token");	// 토큰
		String userOtp = request.getParameter("userOtp");			// MOTP번호
		String otpType = request.getParameter("otpType");			// MOTP타입
		//String SVC_IF_BASE_URL = request.getParameter("SVC_IF_BASE_URL"); //app server URL
		// --------------------------
		// 1. MOTP번호 확인 인터페이스에 보낼 데이터 설정
		// --------------------------
		JSONObject jsonReq = new JSONObject();
		jsonReq.put("ACCESS_TOKEN", accessToken);	// 토큰
		jsonReq.put("USERPW", userOtp);				// MOTP번호
		jsonReq.put("OTPTYPE", otpType);			// MOTP타입
		
		// --------------------------
		// 2. MOTP번호 확인
		// --------------------------
		String strRes = Curl.post(SVC_IF_BASE_URL + "/svcif/motp/check", new String[] {"Content-Type application/json;charset=UTF-8"}, jsonReq.toString());
		System.out.println("[motpLogin] MOTP Check Response: " + strRes);
		
		JSONObject jsonRes = null;
		try {
			jsonRes = (JSONObject) new JSONParser().parse(strRes);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		
		if ( jsonRes == null ) {
			throw new NullPointerException("[motpLogin] MOTP Check Response is null");
		}
		
		return jsonRes;
		
	}
	
	//로그인 완료화면
	@RequestMapping(value = "/spring3/loginSuccess")
	public String loginSuccess(HttpServletRequest request) {
		
//		String userId = request.getParameter("user_id");	// 사용자ID
//		
//		request.setAttribute("SID", sid);
//		request.setAttribute("USER_ID", userId);
		
		return "spring3/login_success";
		
	}
	
	@RequestMapping(value = "/spirng3/sloginSuccess")
	public String sloginSuccess(HttpServletRequest request, @PathVariable String sid) {
		
		request.setAttribute("SID", sid);
		
		return "/ssenstone/login_success";
		
	}

	//모바일 체크
	private boolean isMobile(String userAgent) {

		boolean flag = false;

		String[] mobileOS = {"iPhone","iPod","Android","BlackBerry","windows CE","Nokia","Webos","Opera Mini","SonyEricsson","Opera Mobi","IEMobile"};

		if ( userAgent != null && !"".equals(userAgent) ) {
			for ( String s : mobileOS ) {
				if ( userAgent.indexOf(s) > -1 ) {
					flag = true;
					break;
				}
			}
		}

		return flag;

	}
	
	@RequestMapping(value = "/spring3/a",method = {RequestMethod.GET,RequestMethod.POST})
	public String finish(HttpServletRequest request) {
		
		
		return "spring3/a";
		
	}

}
